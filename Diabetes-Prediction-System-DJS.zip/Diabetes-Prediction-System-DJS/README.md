
## Diabetes Predictor
> Predict Diabetes using Machine Learning.

In this project, our objective is to predict whether the patient has diabetes or not based on various features like *Glucose level, Insulin, Age, BMI*. We will perform all the steps from *Data gathering to Model deployment.* During Model evaluation, we compare various machine learning algorithms on the basis of accuracy_score metric and find the best one. Then we create a web app using Flask which is a python micro framework.



# **Screenshot**

video link : https://viteduin59337-my.sharepoint.com/:v:/g/personal/deepali_shrikhande_vit_edu_in/Ebbfola4PAlAljWco2cXO2wBP_f-lBewS4UByt51ejab5Q?e=ca1Goc

# Installation

- Clone this repository and unzip it.

- After downloading, `cd` into the `flask` directory.

- Begin a new virtual environment with Python 3 and activate it.

- Install the required packages using 
   `pip install -r requirements.txt`

- Execute the command:
   `python app.py`

- Open http://127.0.0.1:5000/ in your browser.
